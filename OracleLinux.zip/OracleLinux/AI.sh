#!/bin/bash

count=0
sleep_duration=10

while true; do
    echo -e "welcome to "
    ./logo.sh
    echo "Choose an option:"
    echo "1. AI-Installer"
    echo "2. AI-Uninstaller"
    echo "3. Exit"

    read -p "Enter your choice (1-3): " option

    case $option in 
        1)
            echo "Welcome to Autointelli Installer..."
            mkdir -p /tmp/Autointelli/InstallLog
            ./AI-Install/AiInstaller.sh
            ;;
        2)
            echo "Welcome to Autointelli Installer..."
            mkdir -p /tmp/Autointelli/UninstallLog
            ./AI-Uninstall/AiUninstaller.sh 
            ;;
        3)
            echo "Exiting"
            exit 0
            ;;
        *)
            ((count++))
            if [ "$count" -ge 2 ]; then
                echo "Invalid option. Exiting script."
                exit 1
            else
                echo "Invalid option. Please enter a number between 1 and 12."
                
                # Countdown loop
                for ((i = $sleep_duration; i > 0; i--)); do
                    echo -ne "Trying again in $i seconds... \r"
                    sleep 1
                done
                echo -ne "\n"
            fi
            ;;
    esac
done