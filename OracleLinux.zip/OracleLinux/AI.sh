#!/bin/bash

echo "Choose an option:"
echo "1. AI-Installer"
echo "2. AI-Uninstaller"
echo "3. Exit"

read -p "Enter your choice (1-3): " option

case $option in 
    1)
        echo "Welcome to Autointelli Installer..."
        ./AI-Install/AiInstaller.sh
        ;;
    2)
        echo "Welcome to Autointelli Installer..."
        ./AI-Uninstall/AiUninstaller.sh 
        ;;
    3)
        echo "Exiting"
        exit 0 >>/tmp/Autointelli/AI.log
        ;;
    *)
        echo "Invalid option. Please enter a number between 1 and 5."
        ;;
esac


