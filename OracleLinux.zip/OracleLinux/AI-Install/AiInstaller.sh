#!/bin/bash
count=0
sleep_duration=10

while true; do
    ./logo.sh
    # Function to check internet connection
    check_internet() {
        if ping -q -c 1 -W 1 google.com >/dev/null; then
            return 0  # Internet connection available
        else
            return 1  # No internet connection
        fi
    }

    # Check internet connection
    if ! check_internet; then
        echo "Warning: Internet connection not available. Some installations may require internet access."
        read -p "Do you want to continue without internet? (y/n): " continue_without_internet
        if [ "$continue_without_internet" != "y" ]; then
            echo "Exiting due to lack of internet connection."
            exit 1
        fi
    fi

    echo "Choose an option:"
    echo " 1. Install Python"
    echo " 2. Install Java"
    echo " 3. Install Maven"
    echo " 4. Install Dependencies"
    echo " 5. Install Nginx"
    echo " 6. Install Database"
    echo " 7. Install Central"
    echo " 8. Install Engine"
    echo " 9. Install IOEngine"
    echo "10. Install Docker"
    echo "11. Install Wildfly"
    echo "12. Install UI"
    echo "13. Run all files"
    echo "14. Exit"

    read -p "Enter your choice (1-14): " option

    case $option in 
        1)
            echo "Running Python Installer File"
            ./PythonInstaller.sh >>/tmp/Autointelli/InstallLog/AiInstaller.log 2>&1
            ;;
        2)
            echo "Running Java Installer File"
            ./JavaInstaller.sh >>/tmp/Autointelli/InstallLog/AiInstaller.log 2>&1
            ;;
        3)
            echo "Running Maven Installer File"
            ./MavenInstaller.sh >>/tmp/Autointelli/InstallLog/AiInstaller.log 2>&1
            ;;
        4)
            echo "Running Dependencies Installer File"
            ./Dependencies.sh >>/tmp/Autointelli/InstallLog/AiInstaller.log 2>&1
            ;;
        5)
            echo "Running Nginx Installer File"
            ./NginxInstaller.sh >>/tmp/Autointelli/InstallLog/AiInstaller.log 2>&1
            ;;
        6)
            echo "Running Database Installer File"
            ./DBDownload.sh >>/tmp/Autointelli/InstallLog/AiInstaller.log 2>&1
            ./DBCopy.sh >>/tmp/Autointelli/InstallLog/AiInstaller.log 2>&1
            ./DBExecution.sh >>/tmp/Autointelli/InstallLog/AiInstaller.log 2>&1
            ;;
        7)
            echo "Running Central Installer File"
            ./CentralInstaller.sh >>/tmp/Autointelli/InstallLog/AiInstaller.log 2>&1
            ;;
        8)
            echo "Running Engine Installer File"
            ./EngineInstaller.sh >>/tmp/Autointelli/InstallLog/AiInstaller.log 2>&1
            ;;
        9)
            echo "Running IOEngine Installer File"
            ./IOEngineInstaller.sh >>/tmp/Autointelli/InstallLog/AiInstaller.log 2>&1
            ;;
        10)
            echo "Running Docker Installer File"
            ./DockerInstaller.sh >>/tmp/Autointelli/InstallLog/AiInstaller.log 2>&1
            ./DockerContainerCreate.sh >>/tmp/Autointelli/InstallLog/AiInstaller.log 2>&1
            ;;
        11)
            echo "Running Wildfly Installer File"
            ./WildflyInstaller.sh >>/tmp/Autointelli/InstallLog/AiInstaller.log 2>&1
            ;;
        12)
            echo "Running UI Installer File"
            ./UIInstaller.sh >>/tmp/Autointelli/InstallLog/AiInstaller.log 2>&1
            ;;
        13)
            echo "Autointelli Complete Installer"
            ./InternetStatus.sh >>/tmp/Autointelli/InstallLog/AiInstaller.log 2>&1
            ./SystemUpdate.sh >>/tmp/Autointelli/InstallLog/AiInstaller.log 2>&1
            ./Dependencies.sh >>/tmp/Autointelli/InstallLog/AiInstaller.log 2>&1
            ./DirectoryCreation.sh >>/tmp/Autointelli/InstallLog/AiInstaller.log 2>&1
            ./PythonInstaller.sh >>/tmp/Autointelli/InstallLog/AiInstaller.log 2>&1
            ./JavaInstaller.sh >>/tmp/Autointelli/InstallLog/AiInstaller.log 2>&1
            ./MavenInstaller.sh >>/tmp/Autointelli/InstallLog/AiInstaller.log 2>&1
            ./DockerInstaller.sh >>/tmp/Autointelli/InstallLog/AiInstaller.log 2>&1
            ./DockerContainerCreate.sh >>/tmp/Autointelli/InstallLog/AiInstaller.log 2>&1
            ./DBDownload.sh >>/tmp/Autointelli/InstallLog/AiInstaller.log 2>&1
            ./DBCopy.sh >>/tmp/Autointelli/InstallLog/AiInstaller.log 2>&1
            ./DBExecution.sh >>/tmp/Autointelli/InstallLog/AiInstaller.log 2>&1
            ./NginxInstaller.sh >>/tmp/Autointelli/InstallLog/AiInstaller.log 2>&1
            ./WildflyInstaller.sh >>/tmp/Autointelli/InstallLog/AiInstaller.log 2>&1
            ./CentralInstaller.sh >>/tmp/Autointelli/InstallLog/AiInstaller.log 2>&1
            ./EngineInstaller.sh >>/tmp/Autointelli/InstallLog/AiInstaller.log 2>&1
            ./OrgRepo.sh >>/tmp/Autointelli/InstallLog/AiInstaller.log 2>&1
            ./IOEngineInstaller.sh >>/tmp/Autointelli/InstallLog/AiInstaller.log 2>&1
            ./UIInstaller.sh >>/tmp/Autointelli/InstallLog/AiInstaller.log 2>&1
            ;;
        14)
            echo "Exiting"
            exit 0 >>/tmp/Autointelli/InstallLog/AiInstaller.log 2>&1
            ;;
        *)
            ((count++))
            if [ "$count" -ge 2 ]; then
                echo "Invalid option. Exiting script."
                exit 1
            else
                echo "Invalid option. Please enter a number between 1 and 12."
                
                # Countdown loop
                for ((i = $sleep_duration; i > 0; i--)); do
                    echo -ne "Trying again in $i seconds... \r"
                    sleep 1
                done
                echo -ne "\n"
            fi
            ;;
    esac
done