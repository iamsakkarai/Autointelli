#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

# Uninstall Maven
echo "Uninstalling Maven..."

# Remove Maven installation directory
sudo rm -rf /opt/aiorch/maven

# Remove Maven environment variable entries from ~/.bashrc
sed -i '/export M2_HOME=\/opt\/aiorch\/maven/d' ~/.bashrc
sed -i '/export PATH=\$PATH:\/opt\/aiorch\/maven\/bin/d' ~/.bashrc

# Reload ~/.bashrc
source ~/.bashrc
check_status

echo "Maven uninstallation completed successfully."
