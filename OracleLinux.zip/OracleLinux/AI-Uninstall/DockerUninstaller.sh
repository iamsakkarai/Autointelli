#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

# Check if Docker is installed
if ! command -v docker &>/dev/null; then
    echo "Docker is not installed. Nothing to uninstall."
    exit 0
fi

# Stop and disable the Docker service
sudo systemctl stop docker
sudo systemctl disable docker

# Remove Docker packages
sudo dnf remove -y docker-ce docker-ce-cli containerd.io
check_status

# Remove Docker configuration and data
sudo rm -rf /var/lib/docker

echo "Docker uninstallation completed successfully."
