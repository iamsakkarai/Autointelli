#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

# Stop WildFly if running
echo "Stopping WildFly..."
/opt/aiorch/engine/bin/StopWildfly.sh
check_status
sleep 5  # Wait for WildFly to stop

# Remove Engine configurations and files
echo "Removing Engine configurations and files..."
rm -f /opt/aiorch/engine/standalone/configuration/*.properties
rm -f /opt/aiorch/engine/standalone/configuration/*.json
rm -f /opt/aiorch/engine/standalone/configuration/standalone-full.xml
rm -f /opt/aiorch/engine/standalone/configuration/multilang.json
rm -f /opt/aiorch/engine/bin/*.sh
rm -rf /opt/aiorch/engine/standalone/deployments/*
check_status

# Start WildFly
echo "Starting WildFly..."
/opt/aiorch/engine/bin/StartWildfly.sh
check_status

echo "Engine uninstallation completed successfully."
