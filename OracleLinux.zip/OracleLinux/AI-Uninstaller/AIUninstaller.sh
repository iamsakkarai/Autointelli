#!/bin/bash

echo "Choose an option:"
echo " 1. Uninstall Python"
echo " 2. Uninstall Java"
echo " 3. Uninstall Maven"
echo " 4. Uninstall Nginx"
echo " 5. Uninstall Central"
echo " 6. Uninstall Engine"
echo " 7. Uninstall Docker"
echo " 8. Uninstall Docker Container"
echo " 9. Uninstall Wildfly"
echo "10. Uninstall UI"
echo "11. Uninstall all files"
echo "12. Exit"

read -p "Enter your choice (1-12): " option

case $option in
    1)
        echo "Running Python Uninstaller"
        ./PythonUninstaller.sh >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1
        if [ $? -eq 0 ]; then
            echo "Python Uninstalled Successfully"
        else
            echo "Error: Failed to uninstall Python. Check /tmp/Autointelli/UninstallLog/AiUninstaller.log for details."
        fi
        ;;
    2)
        echo "Running Java Uninstaller"
        ./JavaUninstaller.sh >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1
        if [ $? -eq 0 ]; then
            echo "Java Uninstalled Successfully"
        else
            echo "Error: Failed to uninstall Java. Check /tmp/Autointelli/UninstallLog/AiUninstaller.log for details."
        fi
        ;;
    3)
        echo "Running Maven Uninstaller"
        ./MavenUninstaller.sh >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1
        if [ $? -eq 0 ]; then
            echo "Maven Uninstalled Successfully"
        else
            echo "Error: Failed to uninstall Maven. Check /tmp/Autointelli/UninstallLog/AiUninstaller.log for details."
        fi
        ;;
    4)
        echo "Running Nginx Uninstaller"
        ./NginxUninstaller.sh >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1
        if [ $? -eq 0 ]; then
            echo "Nginx Uninstalled Successfully"
        else
            echo "Error: Failed to uninstall Nginx. Check /tmp/Autointelli/UninstallLog/AiUninstaller.log for details."
        fi
        ;;
    5)
        echo "Running Central Uninstaller"
        ./CentralUninstaller.sh >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1
        if [ $? -eq 0 ]; then
            echo "Central Uninstalled Successfully"
        else
            echo "Error: Failed to uninstall Central. Check /tmp/Autointelli/UninstallLog/AiUninstaller.log for details."
        fi
        ;;
    6)
        echo "Running Engine Uninstaller"
        ./EngineUninstaller.sh >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1
        if [ $? -eq 0 ]; then
            echo "Engine Uninstalled Successfully"
        else
            echo "Error: Failed to uninstall Engine. Check /tmp/Autointelli/UninstallLog/AiUninstaller.log for details."
        fi
        ;;
    7)
        echo "Running Docker Uninstaller"
        ./DockerUninstaller.sh >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1
        if [ $? -eq 0 ]; then
            echo "Docker Uninstalled Successfully"
        else
            echo "Error: Failed to uninstall Docker. Check /tmp/Autointelli/UninstallLog/AiUninstaller.log for details."
        fi
        ;;
    8)
        echo "Running Docker Container Uninstaller"
        ./DCUninstaller.sh >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1
        if [ $? -eq 0 ]; then
            echo "Docker Container Uninstalled Successfully"
        else
            echo "Error: Failed to uninstall Docker Container. Check /tmp/Autointelli/UninstallLog/AiUninstaller.log for details."
        fi
        ;;
    9)
        echo "Running Wildfly Uninstaller"
        ./WildflyUninstaller.sh >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1
        if [ $? -eq 0 ]; then
            echo "Wildfly Uninstalled Successfully"
        else
            echo "Error: Failed to uninstall Wildfly. Check /tmp/Autointelli/UninstallLog/AiUninstaller.log for details."
        fi
        ;;
    10)
        echo "Running UI Uninstaller"
        ./UIUninstaller.sh >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1
        if [ $? -eq 0 ]; then
            echo "UI Uninstalled Successfully"
        else
            echo "Error: Failed to uninstall UI. Check /tmp/Autointelli/UninstallLog/AiUninstaller.log for details."
        fi
        ;;
    11)
        echo "Running Complete Autointelli Uninstaller"
        ./PythonUninstaller.sh >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1
        ./JavaUninstaller.sh >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1
        ./MavenUninstaller.sh >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1
        ./CentralUninstaller.sh >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1
        ./EngineUninstaller.sh >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1
        ./DockerUninstaller.sh >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1
        ./WildflyUninstaller.sh >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1
        ./NginxUninstaller.sh >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1
        ./UIUninstaller.sh >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1

        if [ $? -eq 0 ]; then
            echo "All components Uninstalled Successfully"
        else
            echo "Error: Failed to uninstall one or more components. Check /tmp/Autointelli/UninstallLog/AiUninstaller.log for details."
        fi
        ;;
    12)
        echo "Exiting"
        exit 0 >>/tmp/Autointelli/UninstallLog/AiUninstaller.log
        ;;
    *)
        echo "Invalid option. Please enter a number between 1 and 12."
        ;;
esac
