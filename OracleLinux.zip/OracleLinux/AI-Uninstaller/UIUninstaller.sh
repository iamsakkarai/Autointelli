#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

echo "Step -99: Change to autointelli directory"
cd /usr/local/autointelli/ >>/tmp/install.log
check_status

echo "Step -113: Stopping supervisord service"
service supervisord stop >>/tmp/install.log
check_status

echo "Step -100: Remove ioengine directory"
rm -rf ioengine/ >>/tmp/install.log
check_status

echo "Step -101: Change directory to /etc/autointelli/"
cd /etc/autointelli/ >>/tmp/install.log
check_status

echo "Step -102: Remove autointelli.conf"
rm -f autointelli.conf >>/tmp/install.log
check_status

echo "Step -103: Change directory to /etc/supervisord.d/"
cd /etc/supervisord.d/ >>/tmp/install.log
check_status

echo "Step -104: Remove autointelli.ini"
rm -f autointelli.ini >>/tmp/install.log
check_status

echo "Step -105: Restart supervisord service"
service supervisord restart >>/tmp/install.log
check_status

echo "Uninstallation completed successfully."
