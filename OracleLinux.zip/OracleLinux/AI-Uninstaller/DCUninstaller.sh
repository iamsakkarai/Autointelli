#!/bin/bash

echo "Choose an option:"
echo "1. Single Container"
echo "2. All Container"
echo "3. Exit"

read -p "Enter your choice (1-3): " option

case $option in 
    1)
        ./SDCUninstaller.sh >>/tmp/Autointelli/UninstallLog/DockerContainerUninstaller.log 2>&1
        ;;
    2)
        ./AllDCUninstaller.sh >>/tmp/Autointelli/UninstallLog/DockerContainerUninstaller.log 2>&1
        ;;
    3)
        echo "Exiting"
        exit 0 >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1
        ;;
    *)
        echo "Invalid option. Please enter a number between 1 and 5."
        ;;
esac
