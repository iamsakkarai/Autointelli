#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully."
        exit 1
    fi
}

# Check if Python is installed
if ! command -v python3.10 &>/dev/null; then
    echo "Python is not installed. Nothing to uninstall."
    exit 0
fi

# Identify the package manager
if command -v apt &>/dev/null; then
    package_manager="apt"
elif command -v yum &>/dev/null; then
    package_manager="yum"
else
    echo "Error: Unsupported package manager. Please uninstall Python manually."
    exit 1
fi

# Uninstall Python using the package manager
echo "Uninstalling Python using $package_manager..."
sudo $package_manager remove -y python3
check_status

# Remove residual configuration files
sudo rm -rf /usr/local/autointelli/ioengine
sudo rm -f ~/.bashrc

echo "Python uninstallation completed successfully."
