#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

# Stop WildFly if running
echo "Stopping WildFly..."
/opt/aiorch/central/bin/StopWildfly.sh >> /tmp/uninstall.log 2>&1
check_status
sleep 5  # Wait for WildFly to stop

# Remove Central configurations and files
echo "Removing Central configurations and files..."
rm -f /opt/aiorch/central/standalone/configuration/*.properties
rm -f /opt/aiorch/central/standalone/configuration/*.xml
rm -f /opt/aiorch/central/standalone/configuration/*.wid
rm -f /opt/aiorch/central/standalone/configuration/*.bpmn2
rm -f /opt/aiorch/central/standalone/configuration/OrchConfig.json
rm -f /opt/aiorch/central/bin/*.sh
rm -rf /opt/aiorch/central/standalone/deployments/*
check_status

# Start WildFly
echo "Starting WildFly..."
/opt/aiorch/central/bin/StartWildfly.sh >> /tmp/uninstall.log 2>&1
check_status

echo "Central uninstallation completed successfully."
