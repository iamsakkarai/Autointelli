#!/bin/bash

install_nginx() {
    # Check if Nginx is already installed
    if ! command -v nginx &>/dev/null; then
        echo "Installing Nginx..."
        sudo yum install -y nginx >> /tmp/Autointelli/Nginxinstall.log
        check_status
    else
        echo "Nginx is already installed. Skipping installation."
    fi
}

enable_and_start_nginx() {
    systemctl enable nginx >> /tmp/Autointelli/Nginxinstall.log
    systemctl start nginx >> /tmp/Autointelli/Nginxinstall.log
    check_status
}

check_status() {
    if systemctl is-active --quiet nginx; then
        echo "Nginx is running."
    else
        echo "Nginx is not running. Performing troubleshooting steps..."
        troubleshoot_nginx
    fi
}

troubleshoot_nginx() {

    
    # Step 2: Edit /etc/nginx/nginx.conf
    echo "Step 2: Editing /etc/nginx/nginx.conf"
    sed -i 's/^ *listen \[:\] 80;/# listen \[:\] 80;/' /etc/nginx/nginx.conf
    
    # Step 3: Restart Nginx
    echo "Step 3: Restarting Nginx"
    systemctl restart nginx
    
    # Step 4: Check Nginx status again
    echo "Step 4: Checking Nginx status"
    check_status
}

# Main script
install_nginx
enable_and_start_nginx
