#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

# Function to prompt for confirmation
confirm() {
    read -p "Are you sure you want to uninstall WildFly? This action cannot be undone. (y/n): " response
    if [[ "$response" != "y" && "$response" != "Y" ]]; then
        echo "WildFly uninstallation canceled. Exiting."
        exit 0
    fi
}

# Check if WildFly is installed
if [ ! -d "/opt/aiorch/engine" ] && [ ! -d "/opt/aiorch/central" ]; then
    echo "WildFly is not installed. Nothing to uninstall."
    exit 0
fi

# Prompt for confirmation before uninstallation
confirm

# Stop WildFly if running
echo "Stopping WildFly..."
/opt/aiorch/engine/bin/jboss-cli.sh --connect command=:shutdown
check_status
sleep 5  # Wait for WildFly to stop

# Remove WildFly directories
echo "Removing WildFly directories..."
rm -rf /opt/aiorch/engine
rm -rf /opt/aiorch/central
check_status

echo "WildFly uninstallation completed successfully."
