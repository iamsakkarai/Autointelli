#!/bin/bash

./logo.sh
# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

# Get a list of all Docker container names
containers=$(docker ps -a --format "{{.Names}}")

# Check if there are any Docker containers
if [ -z "$containers" ]; then
    echo "No Docker containers found."
else
    for container_name in $containers; do
        echo "Docker container: $container_name"
        read -p "Do you want to delete this container? (y/n): " confirmation
        if [ "$confirmation" == "y" ]; then
            echo "Deleting Docker container $container_name..."
            docker rm -f "$container_name"
            check_status
            echo "Docker container $container_name deleted successfully."
        else
            echo "Skipping deletion of Docker container $container_name."
        fi
    done
fi
