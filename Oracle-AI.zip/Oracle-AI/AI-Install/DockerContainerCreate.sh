#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

# Check if the RabbitMQ container already exists
if [ "$(docker network ls -q -f name=autointelli)" ]; then
    echo "Autointelli network already exists. Skipping creation."
else
    docker network create autointelli
    check_status
    echo "Autointelli network created successfully."
fi >> /tmp/Autointelli/DockerNetCreation.log

# RabbitMQ container
if [ "$(docker ps -q -f name=rabbitmq)" ]; then
    echo "RabbitMQ container already exists. Skipping creation."
else
    # Create RabbitMQ container if it doesn't exist
    docker volume create rabbitmq
    echo "RabbitMQ volume created"
    docker run -d --network autointelli --name rabbitmq -e RABBITMQ_DEFAULT_USER=autointelli -e RABBITMQ_DEFAULT_PASSWORD=autointelli -e RABBITMQ_DEFAULT_VHOST=autointelli -p 15672:15672 -p 5672:5672 -v rabbitmq:/var/lib/rabbitmq/mnesia rabbitmq:3-management
    check_status
    echo "RabbitMQ container created successfully"
fi >> /tmp/Autointelli/DockerNetCreation.log

# PostgreSQL container
if [ "$(docker ps -q -f name=postgresql)" ]; then
    echo "PostgreSQL container already exists. Skipping creation."
else
    # Create PostgreSQL container if it doesn't exist
    docker volume create postgresql
    echo "PostgreSQL volume created"
    docker run -d --network autointelli --name postgresql --hostname postgresql -e POSTGRES_USER=autointelli -e POSTGRES_USER=autointelli -e POSTGRES_PASSWORD=autointelli -e POSTGRES_DB=autointelli -e PGDATA=/var/lib/pgsql/data -v postgresql:/var/lib/pgsql/data -p 5432:5432 postgres:14
    check_status
    echo "PostgreSQL container created successfully"
fi  >> /tmp/Autointelli/DockerNetCreation.log

# MongoDB container
if [ "$(docker ps -q -f name=mongodb)" ]; then
    echo "MongoDB container already exists. Skipping creation."
else
    # Create MongoDB container if it doesn't exist
    docker volume create mongo
    echo "MongoDB volume created"
    docker run -d --network autointelli --name mongodb --hostname mongodb -p 27017:27017 -v mongo:/data/db mongo:4.4.16  >> /tmp/Autointelli/DockerNetCreation.log
    check_status
    echo "MongoDB container created successfully"
fi  >> /tmp/Autointelli/DockerNetCreation.log

# Verify that all containers are running
echo "Step -24: Verifying Docker container status..."
if [ "$(docker ps -q -a -f name=rabbitmq -f name=postgresql -f name=mongodb)" ]; then
    echo "All Docker containers are running."
else
    echo "Error: One or more Docker containers are not running. Please check the installation."
    exit 1
fi

echo "Verification of Docker containers completed successfully."
