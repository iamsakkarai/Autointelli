#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

curl -X POST -H "Content-Type: application/json" --user admin:admin 127.0.0.1:8080/kie-wb/rest/organizationalunits -d '{ "name": "autointelli", "description": "Autointelli", "owner": "autointelli", "defaultGroupId": "autointelli" }'
echo "Organizational unit created successfully."

sleep 15

curl -X POST -H "Content-Type: application/json" --user admin:admin 127.0.0.1:8080/kie-wb/rest/repositories -d '{ "name": "autointelli_internal", "description": "Autointelli Internal", "userName": null, "password": null, "gitURL": null, "requestType": "new", "organizationalUnitName": "autointelli" }'
echo "Repository created successfully."

echo "Status code verification completed successfully."
