#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

# Directory path
dir_path="/opt/aiorch"

# Check if the directory exists, if not, create it
if [ ! -d "$dir_path" ]; then
    mkdir -p "$dir_path"
    check_status
fi

# Change into the directory or exit if unsuccessful
cd "$dir_path" || exit 1
check_status

# Check if Maven is already installed
if command -v mvn &>/dev/null; then
    echo "Maven is already installed. Skipping installation."
else
    # Maven Installation
    wget http://dev.autointelli.com/binaries/apache-maven-3.6.3-bin.tar.gz 
    check_status

    tar -zxvf apache-maven-3.6.3-bin.tar.gz 
    check_status

    mv apache-maven-3.6.3 maven 
    check_status

    rm -f apache-maven-3.6.3-bin.tar.gz 
fi

# Autointelli Export
echo "export M2_HOME=/opt/aiorch/maven" >> ~/.bashrc
echo "export PATH=\$PATH:/opt/aiorch/maven/bin" >> ~/.bashrc

echo "Step -36: Reloading ~/.bashrc..."
source ~/.bashrc
check_status

# Verify Maven version
echo "Verifying Maven version..."
mvn -version 

echo "Maven installation and setup completed successfully."
