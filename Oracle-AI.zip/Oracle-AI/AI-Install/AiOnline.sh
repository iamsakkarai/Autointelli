#!/bin/bash
count=0
sleep_duration=10

while true; do
    ./AI-Install/logo.sh
    # Function to check internet connection
    check_internet() {
        if ping -q -c 1 -W 1 google.com >/dev/null; then
            return 0  # Internet connection available
        else
            return 1  # No internet connection
        fi
    }

    # Check internet connection
    if ! check_internet; then
        echo "Warning: Internet connection not available. Some installations may require internet access."
        read -p "Do you want to continue without internet? (y/n): " continue_without_internet
        if [ "$continue_without_internet" != "y" ]; then
            echo "Exiting due to lack of internet connection."
            exit 1
        fi
    fi

    echo "Choose an option:"
    echo " 1. Install Python"
    echo " 2. Install Java"
    echo " 3. Install Maven"
    echo " 4. Install Dependencies"
    echo " 5. Install Nginx"
    echo " 6. Install Docker"
    echo " 7. Install Database"
    echo " 8. Install Central"
    echo " 9. Install Engine"
    echo "10. Install IOEngine"
    echo "11. Install Wildfly"
    echo "12. Install UI"
    echo "13. Install Autointelli"
    echo "14. Exit"

    read -p "Enter your choice (1-14): " option

    case $option in 
        1)
            echo "Running Python Installer File"
            ./AI-Install/PythonInstaller.sh
            ;;
        2)
            echo "Running Java Installer File"
            ./AI-Install/JavaInstaller.sh
            ;;
        3)
            echo "Running Maven Installer File"
            ./AI-Install/MavenInstaller.sh
            ;;
        4)
            echo "Running Dependencies Installer File"
            ./AI-Install/Dependencies.sh
            ;;
        5)
            echo "Running Nginx Installer File"
            ./AI-Install/NginxInstaller.sh
            ;;
        6)
            echo "Running Docker Installer File"
            ./AI-Install/DockerInstaller.sh
            ./AI-Install/DockerContainerCreate.sh
            ;;
        7)
            echo "Running Database Installer File"
            ./AI-Install/DBDownload.sh
            ./AI-Install/DBCopy.sh
            ./AI-Install/DBExecution.sh
            ;;
        8)
            echo "Running Central Installer File"
            ./AI-Install/CentralInstaller.sh
            ;;
        9)
            echo "Running Engine Installer File"
            ./AI-Install/EngineInstaller.sh
            ;;
        10)
            echo "Running IOEngine Installer File"
            ./AI-Install/IOEngineInstaller.sh
            ;;
        
        11)
            echo "Running Wildfly Installer File"
            ./AI-Install/WildflyInstaller.sh
            ;;
        12)
            echo "Running UI Installer File"
            ./AI-Install/UIInstaller.sh
            ;;
        13)
            echo "Autointelli Complete Installer"
            ./AI-Install/InternetStatus.sh
            ./AI-Install/SystemUpdate.sh
            ./AI-Install/Dependencies.sh
            ./AI-Install/DirectoryCreation.sh
            ./AI-Install/PythonInstaller.sh
            ./AI-Install/JavaInstaller.sh
            ./AI-Install/MavenInstaller.sh
            ./AI-Install/DockerInstaller.sh
            ./AI-Install/DockerContainerCreate.sh
            ./AI-Install/DBDownload.sh
            ./AI-Install/DBCopy.sh
            ./AI-Install/DBExecution.sh
            ./AI-Install/NginxInstaller.sh
            ./AI-Install/WildflyInstaller.sh
            ./AI-Install/CentralInstaller.sh
            ./AI-Install/EngineInstaller.sh
            ./AI-Install/OrgRepo.sh
            ./AI-Install/IOEngineInstaller.sh
            ./AI-Install/UIInstaller.sh
            ;;
        14)
            echo "Exiting"
            exit 0
            ;;
        *)
            ((count++))
            if [ "$count" -ge 2 ]; then
                echo "Invalid option. Exiting script."
                exit 1
            else
                echo "Invalid option. Please enter a number between 1 and 12."
                
                # Countdown loop
                for ((i = $sleep_duration; i > 0; i--)); do
                    echo -ne "Trying again in $i seconds... \r"
                    sleep 1
                done
                echo -ne "\n"
            fi
            ;;
    esac
done