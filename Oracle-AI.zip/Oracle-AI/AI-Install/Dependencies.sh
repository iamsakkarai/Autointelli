#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

./AI-Install/DirectoryCreation.sh

sudo yum install -y epel-release
sudo yum install -y yum-utils
sudo yum install -y http://repo.ius.io/ius-release-el7.rpm
sudo yum install -y curl
sudo yum install -y unzip
sudo yum install -y cyrus-sasl-devel
sudo yum install -y openssl-devel
sudo yum install -y openldap-devel
sudo yum install -y libffi-devel
sudo yum install -y zlib-devel
sudo yum install -y gcc
sudo yum install -y make
sudo yum install -y dnf-utils
sudo yum install -y zip
sudo yum install -y wget
sudo yum install -y telnet
sudo yum install -y supervisor

./AI-Install/JavaInstaller.sh

./AI-Install/MavenInstaller.sh

./AI-Install/PythonInstaller.sh

./AI-Install/DockerInstaller.sh
./AI-Install/DockerContainerCreate.sh

./AI-Install/WildflyInstaller.sh