#!/bin/bash

source ~/.bashrc; cd /opt/aiorch/engine/bin/;bash StartWildfly.sh