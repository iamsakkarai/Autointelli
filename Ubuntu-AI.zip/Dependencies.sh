#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

echo "Installing epel-release."
sudo apt install -y epel-release >> /tmp/Autointelli/dependence.log
check_status
while ! grep -q "Complete!" /tmp/Autointelli/dependence.log; do
    echo "Waiting for epel-release installation to complete..."
    sleep 1
done
echo "epel-release installed successfully!!"


echo "Installing apt-utils."
sudo apt install -y apt-utils >> /tmp/Autointelli/dependence.log
check_status
while ! grep -q "Complete!" /tmp/Autointelli/dependence.log; do
    echo "apt-utils installed successfully!!"
    sleep 1
done
echo "apt-utils installed successfully!!"

echo "Installing ius-release-el7."
sudo apt install -y http://repo.ius.io/ius-release-el7.rpm >> /tmp/Autointelli/dependence.log
check_status
while ! grep -q "Complete!" /tmp/Autointelli/dependence.log; do
    echo "ius-release-el7 installed successfully!!"
    sleep 1
done
echo "ius-release-el7 installed successfully!!"

echo "Installing curl."
sudo apt install -y curl >> /tmp/Autointelli/dependence.log
check_status
while ! grep -q "Complete!" /tmp/Autointelli/dependence.log; do
    echo "curl installed successfully!!"
    sleep 1
done
echo "curl installed successfully!!"

echo "Installing unzip."
sudo apt install -y unzip >> /tmp/Autointelli/dependence.log
check_status
while ! grep -q "Complete!" /tmp/Autointelli/dependence.log; do
    echo "unzip installed successfully!!"
    sleep 1
done
echo "unzip installed successfully!!"

echo "Installing cyrus-sasl-devel."
sudo apt install -y cyrus-sasl-devel >> /tmp/Autointelli/dependence.log
check_status
while ! grep -q "Complete!" /tmp/Autointelli/dependence.log; do
    echo "cyrus-sasl-devel installed successfully!!"
    sleep 1
done
echo "cyrus-sasl-devel installed successfully!!"

echo "Installing openssl-devel."
sudo apt install -y openssl-devel >> /tmp/Autointelli/dependence.log
check_status
while ! grep -q "Complete!" /tmp/Autointelli/dependence.log; do
    echo "openssl-devel installed successfully!!"
    sleep 1
done
echo "openssl-devel installed successfully!!"

echo "Installing openldap-devel."
sudo apt install -y openldap-devel >> /tmp/Autointelli/dependence.log
check_status
while ! grep -q "Complete!" /tmp/Autointelli/dependence.log; do
    echo "openldap-devel installed successfully!!"
    sleep 1
done
echo "openldap-devel installed successfully!!"

echo "Installing libffi-devel."
sudo apt install -y libffi-devel >> /tmp/Autointelli/dependence.log
check_status
while ! grep -q "Complete!" /tmp/Autointelli/dependence.log; do
    echo "libffi-devel installed successfully!!"
    sleep 1
done
echo "libffi-devel installed successfully!!"

echo "Installing zlib-devel."
sudo apt install -y zlib-devel >> /tmp/Autointelli/dependence.log
check_status
while ! grep -q "Complete!" /tmp/Autointelli/dependence.log; do
    echo "zlib-devel installed successfully!!"
    sleep 1
done
echo "zlib-devel installed successfully!!"

echo "Installing gcc."
sudo apt install -y gcc >> /tmp/Autointelli/dependence.log
check_status
while ! grep -q "Complete!" /tmp/Autointelli/dependence.log; do
    echo "gcc installed successfully!!"
    sleep 1
done
echo "gcc installed successfully!!"

echo "Installing make."
sudo apt install -y make >> /tmp/Autointelli/dependence.log
check_status
while ! grep -q "Complete!" /tmp/Autointelli/dependence.log; do
    echo "make installed successfully!!"
    sleep 1
done
echo "make installed successfully!!"

echo "Installing dnf-utils."
sudo apt install -y dnf-utils >> /tmp/Autointelli/dependence.log
check_status
while ! grep -q "Complete!" /tmp/Autointelli/dependence.log; do
    echo "dnf-utils installed successfully!!"
    sleep 1
done
echo "dnf-utils installed successfully!!"

echo "Installing zip."
sudo apt install -y zip >> /tmp/Autointelli/dependence.log
check_status
while ! grep -q "Complete!" /tmp/Autointelli/dependence.log; do
    echo "zip installed successfully!!"
    sleep 1
done
echo "zip installed successfully!!"

echo "Installing wget."
sudo apt install -y wget >> /tmp/Autointelli/dependence.log
check_status
while ! grep -q "Complete!" /tmp/Autointelli/dependence.log; do
    echo "wget installed successfully!!"
    sleep 1
done
echo "wget installed successfully!!"

echo "Installing telnet."
sudo apt install -y telnet >> /tmp/Autointelli/dependence.log
check_status
while ! grep -q "Complete!" /tmp/Autointelli/dependence.log; do
    echo "telnet installed successfully!!"
    sleep 1
done
echo "telnet installed successfully!!"

echo "Installing supervisor."
sudo apt install supervisor -y >> /tmp/Autointelli/dependence.log
check_status
while ! grep -q "Complete!" /tmp/Autointelli/dependence.log; do
    echo "supervisor installed successfully!!"
    sleep 1
done
echo "telnet installed successfully!!"


# Wait for the completion message
while ! grep -q "Complete!" /tmp/Autointelli/dependence.log; do
    sleep 5
done

# Check if all dependencies are installed successfully
if grep -q "Error:" /tmp/Autointelli/dependence.log; then
    echo "Error: Some dependencies installation failed. Check /tmp/Autointelli/dependence.log for details."
else
    echo "All dependencies installed successfully."
fi
