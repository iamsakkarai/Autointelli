#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

# Get all Docker container names
all_containers=$(docker ps -a --format "{{.Names}}")

# Echo numbered list of containers
echo "Choose a container to delete:"
count=1
for container_name in $all_containers; do
    echo "$count. $container_name"
    ((count++))
done

# Prompt user to choose option(s)
read -p "Enter the container number(s) to delete (space-separated): " container_numbers

# Convert space-separated input to an array
IFS=' ' read -ra selected_numbers <<< "$container_numbers"

# Check if the entered numbers are valid and delete the corresponding containers
for selected_number in "${selected_numbers[@]}"; do
    if [ $selected_number -ge 1 ] && [ $selected_number -le $count ]; then
        container_name=${all_containers[$((selected_number - 1))]}
        echo "Deleting Docker container: $container_name..."
        docker rm -f "$container_name"
        check_status
        echo "Docker container $container_name deleted successfully."
    else
        echo "Invalid option: $selected_number. Please choose a valid number."
    fi
done
