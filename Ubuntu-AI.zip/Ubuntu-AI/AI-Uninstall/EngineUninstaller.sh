#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

# Function to prompt for confirmation
confirm() {
    read -p "Are you sure you want to proceed? (y/n): " response
    if [[ "$response" != "y" && "$response" != "Y" ]]; then
        echo "Operation canceled. Exiting."
        exit 0
    fi
}

# Check if Engine installation directory exists
if [ ! -d "/opt/aiorch/engine" ]; then
    echo "Error: Engine installation directory '/opt/aiorch/engine' not found. Exiting."
    exit 1
fi

# Stop WildFly if running
echo "Stopping WildFly..."
/opt/aiorch/engine/bin/StopWildfly.sh
check_status
sleep 5  # Wait for WildFly to stop

# Confirm before removing Engine configurations and files
confirm

# Remove Engine configurations and files if they exist
echo "Removing Engine configurations and files..."
rm -rf /opt/aiorch/engine/standalone/configuration/*.properties
rm -rf /opt/aiorch/engine/standalone/configuration/*.json
rm -rf /opt/aiorch/engine/standalone/configuration/standalone-full.xml
rm -rf /opt/aiorch/engine/standalone/configuration/multilang.json
rm -rf /opt/aiorch/engine/bin/*.sh
rm -rf /opt/aiorch/engine/standalone/deployments/*
check_status

echo "Engine uninstallation completed successfully."
