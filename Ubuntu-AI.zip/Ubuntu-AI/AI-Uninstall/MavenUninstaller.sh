#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

# Function to prompt for confirmation
confirm() {
    read -p "Are you sure you want to proceed? (y/n): " response
    if [[ "$response" != "y" && "$response" != "Y" ]]; then
        echo "Operation canceled. Exiting."
        exit 0
    fi
}

# Uninstall Maven
echo "Uninstalling Maven..."

# Check if the Maven installation directory exists
if [ -d "/opt/aiorch/maven" ]; then
    # Prompt for confirmation before deleting Maven installation directory
    confirm

    # Remove Maven installation directory
    sudo rm -rf /opt/aiorch/maven
    check_status
else
    echo "Error: The Maven installation directory does not exist. Exiting."
    exit 1
fi

# Remove Maven environment variable entries from ~/.bashrc
sed -i '/export M2_HOME=\/opt\/aiorch\/maven/d' ~/.bashrc
sed -i '/export PATH=\$PATH:\/opt\/aiorch\/maven\/bin/d' ~/.bashrc

# Reload ~/.bashrc
source ~/.bashrc
check_status

echo "Maven uninstallation completed successfully."
