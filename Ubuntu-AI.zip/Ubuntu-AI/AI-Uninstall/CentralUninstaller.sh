#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

# Function to prompt for confirmation
confirm() {
    read -p "Are you sure you want to proceed? (y/n): " response
    if [[ "$response" != "y" && "$response" != "Y" ]]; then
        echo "Operation canceled. Exiting."
        exit 0
    fi
}

# Check if WildFly installation directory exists
if [ ! -d "/opt/aiorch/central" ]; then
    echo "Error: WildFly installation directory '/opt/aiorch/central' not found. Exiting."
    exit 1
fi

# Stop WildFly if running
echo "Stopping WildFly..."
/opt/aiorch/central/bin/StopWildfly.sh
check_status
sleep 5  # Wait for WildFly to stop

# Confirm before removing Central configurations and files
confirm

# Remove Central configurations and files if they exist
echo "Removing Central configurations and files..."
rm -rf /opt/aiorch/central/standalone/configuration/*.properties
rm -rf /opt/aiorch/central/standalone/configuration/*.xml
rm -rf /opt/aiorch/central/standalone/configuration/*.wid
rm -rf /opt/aiorch/central/standalone/configuration/*.bpmn2
rm -rf /opt/aiorch/central/standalone/configuration/OrchConfig.json
rm -rf /opt/aiorch/central/bin/*.sh
rm -rf /opt/aiorch/central/standalone/deployments/*
check_status

echo "Central uninstallation completed successfully."
