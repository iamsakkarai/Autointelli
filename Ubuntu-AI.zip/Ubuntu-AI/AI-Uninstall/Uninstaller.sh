#!/bin/bash
count=0
sleep_duration=10

while true; do
    ./logo.sh
    echo "Choose an option:"
    echo " 1. Uninstall Python"
    echo " 2. Uninstall Java"
    echo " 3. Uninstall Maven"
    echo " 4. Uninstall Nginx"
    echo " 5. Uninstall Central"
    echo " 6. Uninstall Engine"
    echo " 7. Uninstall Docker"
    echo " 8. Uninstall Docker Container"
    echo " 9. Uninstall Wildfly"
    echo "10. Uninstall Autointelli"
    echo "11. Exit"

    read -p "Enter your choice (1-12): " option

    case $option in
        1)
            echo "Running Python Uninstaller"
            ./PythonUninstaller.sh >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1
            if [ $? -eq 0 ]; then
                echo "Python Uninstalled Successfully"
            else
                echo "Error: Failed to uninstall Python. Check /tmp/Autointelli/UninstallLog/AiUninstaller.log for details."
            fi
            ;;
        2)
            echo "Running Java Uninstaller"
            ./JavaUninstaller.sh >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1
            if [ $? -eq 0 ]; then
                echo "Java Uninstalled Successfully"
            else
                echo "Error: Failed to uninstall Java. Check /tmp/Autointelli/UninstallLog/AiUninstaller.log for details."
            fi
            ;;
        3)
            echo "Running Maven Uninstaller"
            ./MavenUninstaller.sh >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1
            if [ $? -eq 0 ]; then
                echo "Maven Uninstalled Successfully"
            else
                echo "Error: Failed to uninstall Maven. Check /tmp/Autointelli/UninstallLog/AiUninstaller.log for details."
            fi
            ;;
        4)
            echo "Running Nginx Uninstaller"
            ./NginxUninstaller.sh >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1
            if [ $? -eq 0 ]; then
                echo "Nginx Uninstalled Successfully"
            else
                echo "Error: Failed to uninstall Nginx. Check /tmp/Autointelli/UninstallLog/AiUninstaller.log for details."
            fi
            ;;
        5)
            echo "Running Central Uninstaller"
            ./CentralUninstaller.sh >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1
            if [ $? -eq 0 ]; then
                echo "Central Uninstalled Successfully"
            else
                echo "Error: Failed to uninstall Central. Check /tmp/Autointelli/UninstallLog/AiUninstaller.log for details."
            fi
            ;;
        6)
            echo "Running Engine Uninstaller"
            ./EngineUninstaller.sh >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1
            if [ $? -eq 0 ]; then
                echo "Engine Uninstalled Successfully"
            else
                echo "Error: Failed to uninstall Engine. Check /tmp/Autointelli/UninstallLog/AiUninstaller.log for details."
            fi
            ;;
        7)
            echo "Running Docker Uninstaller"
            ./DockerUninstaller.sh >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1
            if [ $? -eq 0 ]; then
                echo "Docker Uninstalled Successfully"
            else
                echo "Error: Failed to uninstall Docker. Check /tmp/Autointelli/UninstallLog/AiUninstaller.log for details."
            fi
            ;;
        8)
            echo "Running Docker Container Uninstaller"
            ./AI-Uninstall/DCUninstaller.sh
            if [ $? -eq 0 ]; then
                echo "Docker Container Uninstalled Successfully"
            else
                echo "Error: Failed to uninstall Docker Container. Check /tmp/Autointelli/UninstallLog/AiUninstaller.log for details."
            fi
            ;;
        9)
            echo "Running Wildfly Uninstaller"
            ./WildflyUninstaller.sh >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1
            if [ $? -eq 0 ]; then
                echo "Wildfly Uninstalled Successfully"
            else
                echo "Error: Failed to uninstall Wildfly. Check /tmp/Autointelli/UninstallLog/AiUninstaller.log for details."
            fi
            ;;
        10)
            confirmation_response="y"

            # Function to prompt for confirmation (unused in this version)
            confirm() {
            read -p "Are you sure you want to uninstall all components? This action cannot be undone. (y/n): " response
            if [[ "$response" != "y" && "$response" != "Y" ]]; then
            echo "Operation canceled. Exiting."
            exit 0
            fi
            }

            # Simulate automatic confirmation
            echo "Automatic confirmation: Uninstalling all components..."

            # Run uninstallation scripts for various components
            ./PythonUninstaller.sh >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1
            ./JavaUninstaller.sh >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1
            ./MavenUninstaller.sh >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1
            ./CentralUninstaller.sh >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1
            ./EngineUninstaller.sh >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1
            ./DockerUninstaller.sh >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1
            ./WildflyUninstaller.sh >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1
            ./NginxUninstaller.sh >>/tmp/Autointelli/UninstallLog/AiUninstaller.log 2>&1
            # Check the exit code and print the corresponding message
            if [ $? -eq 0 ]; then
            echo "All components Uninstalled Successfully"
            else
            echo "Error: Failed to uninstall one or more components. Check /tmp/Autointelli/UninstallLog/AiUninstaller.log for details."
            fi
            ;;
        11)
            echo "Exiting"
            exit 0
            ;;
        *)
            ((count++))
            if [ "$count" -ge 2 ]; then
                echo "Invalid option. Exiting script."
                exit 1
            else
                echo "Invalid option. Please enter a number between 1 and 12."
                
                # Countdown loop
                for ((i = $sleep_duration; i > 0; i--)); do
                    echo -ne "Trying again in $i seconds... \r"
                    sleep 1
                done
                echo -ne "\n"
            fi
            ;;
    esac
done