#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

# Function to prompt for confirmation
confirm() {
    read -p "Are you sure you want to uninstall Docker? This action cannot be undone. (y/n): " response
    if [[ "$response" != "y" && "$response" != "Y" ]]; then
        echo "Docker uninstallation canceled. Exiting."
        exit 0
    fi
}

# Check if Docker is installed
if ! command -v docker &>/dev/null; then
    echo "Docker is not installed. Nothing to uninstall."
    exit 0
fi

# Prompt for confirmation before uninstallation
confirm

# Stop and disable the Docker service
sudo systemctl stop docker
sudo systemctl disable docker

# Remove Docker packages
sudo dnf remove -y docker-ce docker-ce-cli containerd.io
check_status

# Remove Docker configuration and data
sudo rm -rf /var/lib/docker

echo "Docker uninstallation completed successfully."
