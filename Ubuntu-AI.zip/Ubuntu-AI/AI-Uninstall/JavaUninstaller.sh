#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

# Function to prompt for confirmation
confirm() {
    read -p "Are you sure you want to proceed? (y/n): " response
    if [[ "$response" != "y" && "$response" != "Y" ]]; then
        echo "Operation canceled. Exiting."
        exit 0
    fi
}

# Uninstall Java
echo "Uninstalling Java..."

# Check if the Java installation directory exists
if [ -d "/opt/aiorch/java" ]; then
    # Prompt for confirmation before deleting Java installation directory
    confirm

    # Remove Java installation directory
    sudo rm -rf /opt/aiorch/java
    check_status
else
    echo "Error: The Java installation directory does not exist. Exiting."
    exit 1
fi

# Remove Java environment variable entries from ~/.bashrc
sed -i '/export JAVA_HOME=\/opt\/aiorch\/java/d' ~/.bashrc
sed -i '/export PATH=\$PATH:\/opt\/aiorch\/java\/bin/d' ~/.bashrc

# Reload ~/.bashrc
source ~/.bashrc
check_status

echo "Java uninstallation completed successfully."
