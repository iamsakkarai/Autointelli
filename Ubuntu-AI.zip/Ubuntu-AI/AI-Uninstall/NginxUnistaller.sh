#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

# Check if Nginx is installed
if ! command -v nginx &>/dev/null; then
    echo "Nginx is not installed. Nothing to uninstall."
    exit 0
fi

# Stop Nginx service
sudo systemctl stop nginx
check_status

# Disable Nginx service
sudo systemctl disable nginx
check_status

# Remove Nginx service file
sudo rm -f /etc/systemd/system/nginx.service
check_status

# Remove Nginx package
sudo yum remove -y nginx
check_status

# Remove Nginx configuration and data
sudo rm -rf /etc/nginx /var/log/nginx /var/cache/nginx /usr/share/nginx
check_status

echo "Nginx uninstallation completed successfully."
