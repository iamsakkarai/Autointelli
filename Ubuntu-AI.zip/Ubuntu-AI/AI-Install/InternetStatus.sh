#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

# Check internet connectivity
if ping -c 3 8.8.8.8 > /dev/null 2>&1; then
    echo "Internet connection is available. Proceeding with the installation steps..."
else
    echo "Error: No internet connection. Exiting."
    exit 1
fi
