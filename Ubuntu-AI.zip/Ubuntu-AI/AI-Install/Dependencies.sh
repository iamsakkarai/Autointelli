#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

./AI-Install/DirectoryCreation.sh

# Function to install a package
install_package() {
    package_name=$1
    echo "Installing $package_name."
    sudo apt install -y "$package_name"
    check_status
    echo "$package_name installed successfully!!"
}

# List of packages to install
packages=(
    supervisor
    make
    gcc
    apt-transport-https
    curl
    software-properties-common
    libsasl2-dev
    libssl-dev
    libldap2-dev
    unzip
    zip
    wget
    telnet
    vim
    net-tools
    python3-pip
)

# Install each package
for package in "${packages[@]}"; do
    install_package "$package"
done

# Wait for the completion message
while ! grep -q "Complete!" ; do
    sleep 5
done

# Check if all dependencies are installed successfully
if grep -q "Error:" ; then
    echo "Error: Some dependencies installation failed. Check for details."
else
    echo "All dependencies installed successfully."
fi

./AI-Install/JavaInstaller.sh

./AI-Install/MavenInstaller.sh

./AI-Install/PythonInstaller.sh

./AI-Install/DockerInstaller.sh
./AI-Install/DockerContainerCreate.sh

./AI-Install/WildflyInstaller.sh