#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

./AI-Install/DirectoryCreation


sudo apt -y install supervisor
sudo apt -y install make
sudo apt -y install gcc
sudo apt -y install apt-transport-https
sudo apt -y install curl
sudo apt -y install software-properties-common
sudo apt -y install libsasl2-dev
sudo apt -y install libssl-dev
sudo apt -y install libldap2-dev
sudo apt -y install unzip
sudo apt -y install zip
sudo apt -y install wget
sudo apt -y install telnet


./AI-Install/JavaInstaller.sh

./AI-Install/MavenInstaller.sh

./AI-Install/PythonInstaller.sh

./AI-Install/DockerInstaller.sh
./AI-Install/DockerContainerCreate.sh

./AI-Install/WildflyInstaller.sh
