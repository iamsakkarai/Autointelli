#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

#supervisor
echo "Installing supervisor."
sudo apt install -y supervisor
check_status
while ! grep -q "Complete!"  do
    echo "supervisor installed successfully!!"
    sleep 1
done
echo "supervisor installed successfully!!"

#make
echo "Installing make."
sudo apt install -y make
check_status
while ! grep -q "Complete!"  do
    echo "make installed successfully!!"
    sleep 1
done
echo "make installed successfully!!"

#gcc
echo "Installing gcc."
sudo apt install -y gcc
check_status
while ! grep -q "Complete!"  do
    echo "gcc installed successfully!!"
    sleep 1
done
echo "gcc installed successfully!!"

#apt-transport-https
echo "Installing apt-transport-https."
sudo apt install -y apt-transport-https
check_status
while ! grep -q "Complete!"  do
    echo "apt-transport-https installed successfully!!"
    sleep 1
done
echo "apt-transport-https installed successfully!!"

#curl
echo "Installing curl."
sudo apt install -y curl
check_status
while ! grep -q "Complete!"  do
    echo "curl installed successfully!!"
    sleep 1
done
echo "curl installed successfully!!"

#software-properties-common
echo "Installing software-properties-common."
sudo apt install -y software-properties-common
check_status
while ! grep -q "Complete!"  do
    echo "software-properties-common installed successfully!!"
    sleep 1
done
echo "software-properties-common installed successfully!!"

#libsasl2-dev
echo "Installing libsasl2-dev."
sudo apt install -y libsasl2-dev
check_status
while ! grep -q "Complete!"  do
    echo "libsasl2-dev installed successfully!!"
    sleep 1
done
echo "libsasl2-dev installed successfully!!"

#libssl-dev
echo "Installing libssl-dev."
sudo apt install -y libssl-dev
check_status
while ! grep -q "Complete!"  do
    echo "libssl-dev installed successfully!!"
    sleep 1
done
echo "libssl-dev installed successfully!!"

#software-properties-common
echo "Installing libldap2-dev."
sudo apt install -y libldap2-dev
check_status
while ! grep -q "Complete!"  do
    echo "libldap2-dev installed successfully!!"
    sleep 1
done
echo "libldap2-dev installed successfully!!"


# Wait for the completion message
while ! grep -q "Complete!" do
    sleep 5
done

# Check if all dependencies are installed successfully
if grep -q "Error:"; then
    echo "Error: Some dependencies installation failed. Check for details."
else
    echo "All dependencies installed successfully."
fi
