#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

# Directory path
dir_path="/tmp/db"

# Check if the directory exists, if not, create it
if [ ! -d "$dir_path" ]; then
    mkdir -p "$dir_path"
    check_status
fi

# Change into the directory or exit if unsuccessful
cd "$dir_path" || exit 1
check_status

# Downloading database files...
wget http://dev.autointelli.com/binaries/initial_data.sql
wget http://dev.autointelli.com/binaries/ainovac.sql
wget http://dev.autointelli.com/binaries/kiewb_schema.sql
wget http://dev.autointelli.com/binaries/kiewb_data.sql
wget http://dev.autointelli.com/binaries/kieserver_data.sql

check_status
