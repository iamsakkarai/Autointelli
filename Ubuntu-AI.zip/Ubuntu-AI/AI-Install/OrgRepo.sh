#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

# Function to check the HTTP status code
check_http_status() {
    if [ $1 -eq 200 ] || [ $1 -eq 202 ]; then
        echo "HTTP Status Code: $1 - Success"
    else
        echo "Error: Unexpected HTTP Status Code: $1. Exiting."
        exit 1
    fi
}

echo "Step -90: Create organizational unit"
response=$(curl -s -w "%{http_code}" -X POST -H "Content-Type: application/json" --user admin:admin 127.0.0.1:8080/kie-wb/rest/organizationalunits -d '{ "name": "autointelli", "description": "Autointelli", "owner": "autointelli", "defaultGroupId": "autointelli" }')
check_http_status "$response"
echo "Organizational unit created successfully."

sleep 15

echo "Step -91: Create repository"
response=$(curl -s -w "%{http_code}" -X POST -H "Content-Type: application/json" --user admin:admin 127.0.0.1:8080/kie-wb/rest/repositories -d '{ "name": "autointelli_internal", "description": "Autointelli Internal", "userName": null, "password": null, "gitURL": null, "requestType": "new", "organizationalUnitName": "autointelli" }')
check_http_status "$response"
echo "Repository created successfully."

echo "Status code verification completed successfully."
