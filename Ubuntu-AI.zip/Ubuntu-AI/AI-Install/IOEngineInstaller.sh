#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

# Directory path
dir_path="/usr/local/autointelli"

# Check if the directory exists, if not, create it
if [ ! -d "$dir_path" ]; then
    mkdir -p "$dir_path" || { echo "Error: Could not create directory. Exiting." ; exit 1; }
    check_status
fi

# Change into the directory or exit if unsuccessful
cd "$dir_path" || { echo "Error: Could not change into directory. Exiting." ; exit 1; }
check_status

wget http://dev.autointelli.com/binaries/ioengine.tar.gz 
check_status

tar -zxvf ioengine.tar.gz 
check_status

rm -f ioengine.tar.gz 
check_status

ls 
check_status

# Directory path
dir_path="/etc/autointelli"

# Check if the directory exists, if not, create it
if [ ! -d "$dir_path" ]; then
    mkdir -p "$dir_path" || { echo "Error: Could not create directory. Exiting." ; exit 1; }
    check_status
fi

# Change into the directory or exit if unsuccessful
cd "$dir_path" || { echo "Error: Could not change into directory. Exiting." ; exit 1; }
check_status

wget http://dev.autointelli.com/binaries/autointelli_etc.conf -O autointelli.conf 
check_status

sed -i 's/#@#VIP#@#/localhost/g' autointelli.conf 
check_status

cd /etc/supervisord.d/ || exit 1 
check_status

wget http://dev.autointelli.com/binaries/autointelli.ini -O autointelli.conf 
check_status

service supervisord restart 
check_status

mv autointelli.conf autointelli.ini 
check_status

service supervisord restart 
check_status

supervisorctl status autointelli: 
check_status
