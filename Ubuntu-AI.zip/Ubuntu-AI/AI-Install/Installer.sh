#!/bin/bash
count=0
sleep_duration=10

while true; do
    ./logo.sh
    # Function to check internet connection
    check_internet() {
        if ping -q -c 1 -W 1 google.com >/dev/null; then
            return 0  # Internet connection available
        else
            return 1  # No internet connection
        fi
    }

    # Check internet connection
    if ! check_internet; then
        echo "Warning: Internet connection not available. Some installations may require internet access."
        read -p "Do you want to continue without internet? (y/n): " continue_without_internet
        if [ "$continue_without_internet" != "y" ]; then
            echo "Exiting due to lack of internet connection."
            exit 1
        fi
    fi

    echo "Choose an option:"
    echo "1. Automate Install"
    echo "2. Manuall Install"
    echo "3. Exit"

    read -p "Enter your choice (1-3): " option

    case $option in 
        1)
            echo "Running Dependencied Installer File"
            bash /root/Autointelli/Ubuntu-AI/AI-Install/Full.sh
            ;;
        2)
            echo "Running Database Insaller File"
            bash /root/Autointelli/Ubuntu-AI/AI-Install/Manual.sh
            ;;
        3)
            echo "Exiting"
            exit 0 
            ;;
        *)
            ((count++))
            if [ "$count" -ge 2 ]; then
                echo "Invalid option. Exiting script."
                exit 1
            else
                echo "Invalid option. Please enter a number between 1 and 12."
                
                # Countdown loop
                for ((i = $sleep_duration; i > 0; i--)); do
                    echo -ne "Trying again in $i seconds... \r"
                    sleep 1
                done
                echo -ne "\n"
            fi
            ;;
    esac
done