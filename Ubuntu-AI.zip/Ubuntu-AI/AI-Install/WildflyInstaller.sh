#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

# Directory path
dir_path="/opt/aiorch"

# Check if the directory exists, if not, create it
if [ ! -d "$dir_path" ]; then
    mkdir -p "$dir_path"
    check_status
fi

# Change into the directory or exit if unsuccessful
cd "$dir_path" || exit 1
check_status

# WildFly Installation
wget http://dev.autointelli.com/binaries/wildfly-10.0.0.Final.zip 
check_status

unzip wildfly-10.0.0.Final.zip 
check_status

cp -rvf wildfly-10.0.0.Final engine 
check_status

mv wildfly-10.0.0.Final central 
check_status

rm -f wildfly-10.0.0.Final.zip 
check_status

echo "WildFly installation completed successfully."
