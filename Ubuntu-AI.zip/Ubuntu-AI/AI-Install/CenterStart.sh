#!/bin/bash

source ~/.bashrc; cd /opt/aiorch/central/bin/;bash StartWildfly.sh