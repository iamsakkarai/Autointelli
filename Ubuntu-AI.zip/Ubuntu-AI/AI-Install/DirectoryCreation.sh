#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

create_directory() {
    directory=$1
    if [ ! -d "$directory" ]; then
        mkdir -p "$directory"
        check_status
        echo "Directory $directory created."
    else
        echo "Directory $directory already exists. Skipping creation."
    fi
}

create_directory /opt/aiorch
create_directory /etc/autointelli
create_directory /var/log/autointelli
create_directory /var/log/autointelli_proc
create_directory /usr/local/autointelli
create_directory /tmp/db
create_directory /tmp/central
create_directory /tmp/engine

echo "All Directory created successfully.!!"