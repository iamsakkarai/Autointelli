#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

# Directory path
dir_path="/opt/aiorch"

# Check if the directory exists, if not, create it
if [ ! -d "$dir_path" ]; then
    mkdir -p "$dir_path"
    check_status
fi

# Change into the directory or exit if unsuccessful
cd "$dir_path" || exit 1
check_status

# Check if Java is already installed
if command -v java || /opt/aiorch/java/ &>/dev/null; then
    echo "Java is already installed. Skipping installation."
else
    # Java installation
    wget http://dev.autointelli.com/binaries/jdk-8u211-linux-x64.tar.gz 
    check_status

    tar -zxvf jdk-8u211-linux-x64.tar.gz 
    check_status

    sleep 10

    mv openlogic-openjdk-8u392-b08-linux-x64/ java 
    check_status

    chmod -R +x /opt/aiorch/java/bin/* 
    check_status

    rm -f jdk-8u211-linux-x64.tar.gz 
    check_status
fi

# Autointelli Export
echo "export JAVA_HOME=/opt/aiorch/java" >> ~/.bashrc
echo "export PATH=\$PATH:/opt/aiorch/java/bin" >> ~/.bashrc
source ~/.bashrc
check_status

# Verify Java version
echo "Verifying Java version..."
java -version 

echo "Java installation and setup completed successfully."
