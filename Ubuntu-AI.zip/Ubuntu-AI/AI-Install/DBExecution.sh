#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

cd /tmp/db/ || exit 1
echo "Directory moved"
check_status
#Executing DB Dump in PostgreSQL container...
docker exec -it postgresql psql -U autointelli -f /tmp/initial_data.sql
docker exec -it postgresql psql -U autointelli -f /tmp/ainovac.sql
docker exec -it postgresql psql -U kiewb -f /tmp/kiewb_schema.sql
docker exec -it postgresql psql -U kiewb -f /tmp/kiewb_data.sql
docker exec -it postgresql psql -U kieserver -f /tmp/kieserver_data.sql
