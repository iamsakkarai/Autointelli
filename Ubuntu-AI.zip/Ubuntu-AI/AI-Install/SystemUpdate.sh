#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

# Display message after system update
echo "System Updating"
sudo apt update -y
check_status

# Display message after system update
echo "System update completed successfully.!!"
