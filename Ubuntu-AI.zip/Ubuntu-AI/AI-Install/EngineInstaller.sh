#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

# Directory path
dir_path="/tmp/engine"

# Check if the directory exists, if not, create it
if [ ! -d "$dir_path" ]; then
    mkdir -p "$dir_path" || { 
        echo "Error: Could not create directory. Exiting."; 
        exit 1; 
    }
    check_status
fi

# Change into the directory or exit if unsuccessful
cd "$dir_path" || { 
    echo "Error: Could not change into directory. Exiting."; 
    exit 1; 
}
check_status

# Download and unzip Engine
wget http://dev.autointelli.com/binaries/Engine.zip 
check_status

unzip Engine.zip 
check_status

# Navigate to Configurations directory
cd Engine/Configurations || exit 1 
check_status

# Update standalone-full.xml and multilang.json
sed -i 's/#@#VIP#@#/localhost/g' standalone-full.xml 
check_status

sed -i 's/#@#VIP#@#/localhost/g' multilang.json 
check_status

# Copy configuration files
yes | cp -f *.properties *.json standalone-full.xml /opt/aiorch/engine/standalone/configuration/ 
check_status

# Copy scripts to bin directory
cp *.sh /opt/aiorch/engine/bin/ 
check_status

# Navigate to Deployments directory
cd /tmp/engine/Engine/Deployments/ || exit 1 
check_status

# Copy deployment files
cp * /opt/aiorch/engine/standalone/deployments/ 
check_status

# Add alias for tailing server log to .bashrc
echo "alias tails='tail -f /opt/aiorch/engine/standalone/log/server.log'" >> ~/.bashrc

source ~/.bashrc 
check_status

./AI-Instal/EngineStart.sh

sleep 5

log_file="/opt/aiorch/engine/standalone/log/server.log"
target_string="Deployed \"kie-server.war\" (runtime-name : \"kie-server.war\")"

while ! grep -q "$target_string" "$log_file"; do
    echo "Waiting for the line: $target_string in $log_file..."
    sleep 5  # Adjust the sleep interval as needed
done

echo "Found: $target_string"
# Add additional actions if needed after the target string is found
