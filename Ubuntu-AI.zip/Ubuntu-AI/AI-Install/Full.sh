#!/bin/bash
count=0
sleep_duration=10

while true; do
    ./logo.sh
    # Function to check internet connection
    check_internet() {
        if ping -q -c 1 -W 1 google.com >/dev/null; then
            return 0  # Internet connection available
        else
            return 1  # No internet connection
        fi
    }

   # Check internet connection
    if ! check_internet; then
        echo "Warning: Internet connection not available. Some installations may require internet access."
        read -p "Do you want to continue without internet? (y/n): " continue_without_internet
        if [ "$continue_without_internet" != "y" ]; then
            echo "Exiting due to lack of internet connection."
            exit 1
        fi
    fi

echo "Directory Creation..."
bash /root/Autointelli/Ubuntu-AI/AI-Install/DirectoryCreation.sh
echo "Directory Creation Completed..."
echo "Dependencies Installing.."
bash /root/Autointelli/Ubuntu-AI/AI-Install/Dependencies.sh
echo "Dependencies Installation Completed..."
echo "Database Configuring..."
bash /root/Autointelli/Ubuntu-AI/AI-Install/DBDownload.sh
bash /root/Autointelli/Ubuntu-AI/AI-Install/DBCopy.sh
bash /root/Autointelli/Ubuntu-AI/AI-Install/DBExecution.sh
echo "Database Configuration Completed..."
echo "Central Server Configuring"
bash /root/Autointelli/Ubuntu-AI/AI-Install/CentralInstaller.sh
echo "Central Server Configuration Completed..."
echo "Engine Server Configuring..."
bash /root/Autointelli/Ubuntu-AI/AI-Install/EngineInstaller.sh
echo "Engine Server Configuration Completed..."
echo "Add Organisation Repositories..."
bash /root/Autointelli/Ubuntu-AI/AI-Install/OrgRepo.sh
echo "Successfully Reposiroties Updated..."
echo "IOEngine Installing..."
bash /root/Autointelli/Ubuntu-AI/AI-Install/IOEngineInstaller.sh
echo "IOEngine Installation Completed..."
echo "Nginx Installing..."
bash /root/Autointelli/Ubuntu-AI/AI-Install/NginxInstaller.sh
echo "Nginx Installation Completed..."
echo "UI Installing..."
bash /root/Autointelli/Ubuntu-AI/AI-Install/UIInstaller.sh
echo "UI Installation Completed..."
echo "Autointelli Installation Completed Successfully..."