#!/bin/bash
while true; do
    ./logo.sh

    # Function to check internet connection
    check_internet() {
        if ping -q -c 1 -W 1 google.com >/dev/null; then
            return 0  # Internet connection available
        else
            return 1  # No internet connection
        fi
    }

    # Check internet connection
    if ! check_internet; then
        echo "Warning: Internet connection not available. Some installations may require internet access."
        read -p "Do you want to continue without internet? (y/n): " continue_without_internet
        if [ "$continue_without_internet" != "y" ]; then
            echo "Exiting due to lack of internet connection."
            exit 1
        fi
    fi

    # Step 1
    echo "Directory Creation..."
    bash /root/Autointelli/Ubuntu-AI/AI-Install/DirectoryCreation.sh || { echo "Error creating directories. Exiting."; exit 1; }
    echo "Directory Creation Completed..."

    # Step 2
    echo "Dependencies Installing.."
    bash /root/Autointelli/Ubuntu-AI/AI-Install/Dependencies.sh || { echo "Error installing dependencies. Exiting."; exit 1; }
    echo "Dependencies Installation Completed..."

	 # Step 3
	 echo "Database Configuring..."
    bash /root/Autointelli/Ubuntu-AI/AI-Install/DBDownload.sh || { echo "Error installing dependencies. Exiting."; exit 1; }
    bash /root/Autointelli/Ubuntu-AI/AI-Install/DBCopy.sh || { echo "Error installing dependencies. Exiting."; exit 1; }
    bash /root/Autointelli/Ubuntu-AI/AI-Install/DBExecution.sh || { echo "Error installing dependencies. Exiting."; exit 1; }
	 echo "Database Configuration Completed..."
   
    # Step 4
	 echo "Central Server Configuring"
	 bash /root/Autointelli/Ubuntu-AI/AI-Install/CentralInstaller.sh || { echo "Error installing dependencies. Exiting."; exit 1; }
	 echo "Central Server Configuration Completed..."
    
    # Step 5
	 echo "Engine Server Configuring..."
	 bash /root/Autointelli/Ubuntu-AI/AI-Install/EngineInstaller.sh || { echo "Error installing dependencies. Exiting."; exit 1; }
	 echo "Engine Server Configuration Completed..."
    
    # Step 6
	 echo "Add Organisation Repositories..."
	 bash /root/Autointelli/Ubuntu-AI/AI-Install/OrgRepo.sh || { echo "Error installing dependencies. Exiting."; exit 1; }
	 echo "Successfully Reposiroties Updated..."
   
    # Step 7
	 echo "IOEngine Installing..."
	 bash /root/Autointelli/Ubuntu-AI/AI-Install/IOEngineInstaller.sh || { echo "Error installing dependencies. Exiting."; exit 1; }
	 echo "IOEngine Installation Completed..."
   
    # Step 8
	 echo "Nginx Installing..."
	 bash /root/Autointelli/Ubuntu-AI/AI-Install/NginxInstaller.sh || { echo "Error installing dependencies. Exiting."; exit 1; }
	 echo "Nginx Installation Completed..."
   
    # Step 9
	 echo "UI Installing..."
	 bash /root/Autointelli/Ubuntu-AI/AI-Install/UIInstaller.sh || { echo "Error installing dependencies. Exiting."; exit 1; }
	 echo "UI Installation Completed..."

    echo "Autointelli Installation Completed Successfully..."
    exit 0
done