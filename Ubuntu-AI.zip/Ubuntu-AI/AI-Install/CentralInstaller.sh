#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

# Directory path
dir_path="/tmp/central"

# Check if the directory exists, if not, create it
if [ ! -d "$dir_path" ]; then
    mkdir -p "$dir_path" || { echo "Error: Could not create directory. Exiting."; exit 1; }
    check_status
fi

# Change into the directory or exit if unsuccessful
cd "$dir_path" || { echo "Error: Could not change into directory. Exiting."; exit 1; }
check_status


wget http://dev.autointelli.com/binaries/Central.zip 
check_status

unzip Central.zip 
check_status

cd Central/Configurations || exit 1 
check_status

sed -i 's/#@#VIP#@#/localhost/g' standalone-full.xml 
check_status

yes | cp -f *.properties *.xml *.wid *.bpmn2 /opt/aiorch/central/standalone/configuration/ 
check_status

sed -i 's/#@#VIP#@#/localhost/g' OrchConfig.json 
check_status

cp OrchConfig.json /opt/aiorch/central/standalone/configuration/ 
check_status

cp *.sh /opt/aiorch/central/bin 
check_status

cd /tmp/central/Central/Deployments/ || exit 1 
check_status

cp * /opt/aiorch/central/standalone/deployments/ 
check_status

echo "alias tailc='tail -f /opt/aiorch/central/standalone/log/server.log'" >> ~/.bashrc

rm -rvf /tmp/central 
check_status

cd /opt/aiorch/central/bin/ || exit 1 

source ~/.bashrc 
check_status

./StartWildfly.sh
check_status

log_file="/opt/aiorch/central/standalone/log/server.log"
target_string="Deployed \"kie-wb.war\" (runtime-name : \"kie-wb.war\")"
error_string="ERROR"

while ! grep -q "$target_string" "$log_file"; do
    if grep -q "$error_string" "$log_file"; then
        echo "Error found: $error_string in $log_file. Exiting loop."
        break
    fi
    
    echo "Waiting for the line: $target_string in $log_file..."
    sleep 5  # Adjust the sleep interval as needed
done

if grep -q "$target_string" "$log_file"; then
    echo "Found: $target_string"
    # Add additional actions if needed after the target string is found
fi
