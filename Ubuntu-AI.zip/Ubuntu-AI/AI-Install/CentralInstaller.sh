#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

# Directory path
dir_path="/tmp/central"

# Check if the directory exists, if not, create it
if [ ! -d "$dir_path" ]; then
    mkdir -p "$dir_path" || { 
        echo "Error: Could not create directory. Exiting."; 
        exit 1; 
    }
    check_status
fi

# Change into the directory or exit if unsuccessful
cd "$dir_path" || { 
    echo "Error: Could not change into directory. Exiting."; 
    exit 1; 
}
check_status

# Download and unzip Central
wget http://dev.autointelli.com/binaries/Central.zip 
check_status

unzip Central.zip 
check_status

# Navigate to Configurations directory
cd Central/Configurations || exit 1 
check_status

# Update standalone-full.xml
sed -i 's/#@#VIP#@#/localhost/g' standalone-full.xml 
check_status

# Copy configuration files
yes | cp -f *.properties *.xml *.wid *.bpmn2 /opt/aiorch/central/standalone/configuration/ 
check_status

# Update OrchConfig.json
sed -i 's/#@#VIP#@#/localhost/g' OrchConfig.json 
check_status

# Copy OrchConfig.json to configuration directory
cp OrchConfig.json /opt/aiorch/central/standalone/configuration/ 
check_status

# Copy scripts to bin directory
cp *.sh /opt/aiorch/central/bin 
check_status

# Navigate to Deployments directory
cd /tmp/central/Central/Deployments/ || exit 1 
check_status

# Copy deployment files
cp * /opt/aiorch/central/standalone/deployments/ 
check_status

# Add alias for tailing server log to .bashrc
echo "alias tailc='tail -f /opt/aiorch/central/standalone/log/server.log'" >> ~/.bashrc
source ~/.bashrc
check_status

# Clean up temporary directory
rm -rvf /tmp/central 
check_status

# Navigate to bin directory
cd /opt/aiorch/central/bin/
check_status

# Source .bashrc and start Wildfly
source ~/.bashrc
check_status

./StartWildfly.sh

# Wait for the target string in the server log
log_file="/opt/aiorch/central/standalone/log/server.log"
target_string="Deployed \"kie-wb.war\" (runtime-name : \"kie-wb.war\")"

while ! grep -q "$target_string" "$log_file"; do
    echo "Waiting for the line: $target_string in $log_file..."
    sleep 5  # Adjust the sleep interval as needed
done

echo "Found: $target_string"
# Add additional actions if needed after the target string is found
