#!/bin/bash
count=0
sleep_duration=10

while true; do
    ./logo.sh
    # Function to check internet connection
    check_internet() {
        if ping -q -c 1 -W 1 google.com >/dev/null; then
            return 0  # Internet connection available
        else
            return 1  # No internet connection
        fi
    }

    # Check internet connection
    if ! check_internet; then
        echo "Warning: Internet connection not available. Some installations may require internet access."
        read -p "Do you want to continue without internet? (y/n): " continue_without_internet
        if [ "$continue_without_internet" != "y" ]; then
            echo "Exiting due to lack of internet connection."
            exit 1
        fi
    fi

    echo "Choose an option:"
    echo "1. Install Dependencies"
    echo "2. Install Database"
    echo "3. Install Central"
    echo "4. Install Engine"
    echo "5. Adding Repo"
    echo "6. Install IOEngine"
    echo "7. Install UI"
    echo "8. Exit"

    read -p "Enter your choice (1-8): " option

    case $option in 
        1)
            echo "Running Dependencied Installer File"
            ./AI-Install/Dependencies.sh
            ;;
        2)
            echo "Running Database Insaller File"
            ./AI-Install/DBDownload.sh 
            ./AI-Install/DBCopy.sh 
            ./AI-Install/DBExecution.sh 
            ;;
        3)
            echo "Running Central Installer File"
            ./AI-Install/CentralInstaller.sh 
            ;;
        4)
            echo "Running Engine Installer File"
            ./AI-Install/EngineInstaller.sh 
            ;;
        5)
            echo "Adding Repo in Server"
            ./AI-Install/OrgRepo.sh
            ;;
        6)
            echo "Running IOEngine Installer File"
            ./AI-Install/IOEngineInstaller.sh 
            ;;
        7)
            echo "Running UI Installer File"
            ./AI-Install/NginxInstaller.sh
            ./AI-Install/UIInstaller.sh 
            ;;
        8)
            echo "Exiting"
            exit 0 
            ;;
        *)
            ((count++))
            if [ "$count" -ge 2 ]; then
                echo "Invalid option. Exiting script."
                exit 1
            else
                echo "Invalid option. Please enter a number between 1 and 12."
                
                # Countdown loop
                for ((i = $sleep_duration; i > 0; i--)); do
                    echo -ne "Trying again in $i seconds... \r"
                    sleep 1
                done
                echo -ne "\n"
            fi
            ;;
    esac
done