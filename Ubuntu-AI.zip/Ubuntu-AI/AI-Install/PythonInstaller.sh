#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

# Check if Python and pip are already installed
if command -v python3.10 && command -v pip3.10 &>/dev/null; then
    echo "Python is already installed. Skipping installation."
else
    # Change to the temporary directory
    cd /tmp/ || exit 1

    # Download Python source tarball
    wget https://www.python.org/ftp/python/3.10.13/Python-3.10.13.tgz 
    check_status

    # Extract Python source
    tar -zxvf Python-3.10.13.tgz 
    check_status

    # Change to Python source directory
    cd Python-3.10.13 

    # Configure and install Python
    ./configure 
    check_status

    make all 
    check_status

    # Install virtualenv using python3-pip
    sudo apt-get -y install python3-pip
    check_status

    echo "Python is installed successfully."
    # Check Python version
    python_version=$(python3 --version 2>&1)
    echo "Python version: $python_version"

    # Continue with additional installations
    cd /tmp/ || exit 1 
    check_status

    sleep 5

    # Download requirements file
    wget http://dev.autointelli.com/binaries/req.txt.2023 
    check_status

    sleep 5

    # Install virtualenv
    pip3 install virtualenv
    check_status

    sleep 5

    # Create and activate virtual environment
    cd /root || exit 1 
    virtualenv autointelli 
    source autointelli/bin/activate 
    check_status

    sleep 5

    # Install packages using requirements file
    cd /tmp/ || exit 1 
    pip3.10 install -r req.txt.2023 
    check_status

    # Verify installed packages
    echo "Verifying installed packages..." 

    # Verify virtualenv installation
    echo "Checking virtualenv version..."
        virtualenv --version 

    # Verify pip installation
    echo "Checking pip version..."
    pip --version 

    # Verify packages installed in the virtual environment
    echo "Listing installed packages..."
    pip list 

    echo "Installation completed successfully."

    # Add PYTHONPATH to ~/.bashrc
    echo "export PYTHONPATH='/usr/local/autointelli/ioengine'" >> ~/.bashrc 
    check_status
   
    echo "Python installation and setup completed successfully."
fi