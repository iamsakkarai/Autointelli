#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

cd || exit 1
check_status

curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg

echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

sudo apt update

apt-cache policy docker-ce
check_status

sudo apt -y install docker-ce
check_status

systemctl enable docker
check_status

systemctl start docker
check_status

# Verify Docker service status
if systemctl is-active --quiet docker; then
    echo "Docker service is running."
else
    echo "Error: Docker service is not running. Please check the installation."
    exit 1
fi

echo "Docker installation and setup completed successfully."
