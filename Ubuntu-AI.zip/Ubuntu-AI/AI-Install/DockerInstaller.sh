#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

cd || exit 1 >>/tmp/Autointelli/Dockerinstall.log
check_status

apt config-manager --add-repo=https://download.docker.com/linux/centos/docker-ce.repo >>/tmp/Autointelli/install.log
check_status

apt remove -y runc >>/tmp/Autointelli/Dockerinstall.log
check_status

apt install -y docker-ce --nobest >>/tmp/Autointelli/Dockerinstall.log
check_status

systemctl enable docker >>/tmp/Autointelli/Dockerinstall.log
check_status

systemctl start docker >>/tmp/Autointelli/Dockerinstall.log
check_status

# Verify Docker service status
if systemctl is-active --quiet docker; then
    echo "Docker service is running."
else
    echo "Error: Docker service is not running. Please check the installation."
    exit 1
fi

echo "Docker installation and setup completed successfully."
