#!/bin/bash

# Function to check the exit status of the last command
check_status() {
    if [ $? -ne 0 ]; then
        echo "Error: The last command did not execute successfully. Exiting."
        exit 1
    fi
}

cd /tmp/db/ || exit 1 >>/tmp/Autointelli/DBConfig.log
echo "Directory moved" >>/tmp/Autointelli/DBConfig.log
check_status

#Copying database files to PostgreSQL container...
docker cp initial_data.sql postgresql:/tmp
docker cp ainovac.sql postgresql:/tmp
docker cp kiewb_schema.sql postgresql:/tmp
docker cp kiewb_data.sql postgresql:/tmp
docker cp kieserver_data.sql postgresql:/tmp
